//
//  FinalProjectTests.swift
//  FinalProjectTests
//
//  Created by 세근식 on 11/28/24.
//

import Testing
@testable import FinalProject

struct FinalProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
