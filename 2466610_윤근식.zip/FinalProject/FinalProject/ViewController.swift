//
//  ViewController.swift
//  FinalProject
//
//  Created by 세근식 on 11/28/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

